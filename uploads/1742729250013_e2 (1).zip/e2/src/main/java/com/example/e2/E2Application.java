package com.example.e2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E2Application {

	public static void main(String[] args) {
		SpringApplication.run(E2Application.class, args);
	}

}
